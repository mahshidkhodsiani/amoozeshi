<?php
include "functions.php";
?>
<nav class="navbar navbar-lg navbar-dark bg-dark">
    <button class="btn btn-outline-light d-lg-none" onclick="toggleSidebar()">☰</button>
    <h5 class="navbar-brand" >روش های پولسازی</h5>
    <span style="left: 0; color:white"><?=get_name($id)?></span>
</nav>